import { useEffect, useState } from 'react';
import { Navigate, NavLink, Outlet, Route, Routes } from 'react-router-dom';
import { useAuth } from './auth';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Users from './pages/Users';

function Countdown() {
  const { user, logout } = useAuth();
  const [left, setLeft] = useState(0);
  useEffect(() => {
    if (!user) return;
    const expires = Date.parse(user.expiresAt);
    if (!Number.isFinite(expires)) { void logout(); return; }
    let expired = false;
    const tick = () => {
      const seconds = Math.max(0, Math.floor((expires - Date.now()) / 1000));
      setLeft(seconds);
      if (seconds <= 0 && !expired) { expired = true; void logout(); }
    };
    tick();
    const timer = window.setInterval(tick, 1000);
    return () => window.clearInterval(timer);
  }, [user, logout]);
  const hours = Math.floor(left / 3600);
  const minutes = Math.floor((left % 3600) / 60);
  return <span className="text-xs text-slate-500" aria-live="polite">Session ends in {hours}h {minutes}m</span>;
}

function Layout() {
  const { user, logout } = useAuth();
  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `rounded-lg px-3 py-2 text-sm font-medium transition ${isActive ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'}`;
  return (
    <div className="mx-auto min-h-screen max-w-6xl px-4 sm:px-6">
      <header className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 py-4">
        <div className="flex items-center gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-slate-900 text-lg font-bold text-white" aria-hidden="true">E</div>
          <div><p className="font-semibold text-slate-900">Electrical Store</p><p className="text-xs text-slate-500">Management system</p></div>
        </div>
        <nav className="flex items-center gap-1" aria-label="Main navigation">
          <NavLink to="/" end className={linkClass}>Dashboard</NavLink>
          {user?.role === 'ADMIN' && <NavLink to="/users" className={linkClass}>Users</NavLink>}
        </nav>
        <div className="flex flex-wrap items-center gap-3">
          <Countdown />
          <span className="text-sm text-slate-700">{user?.fullName} <span className="text-slate-400">({user?.role})</span></span>
          <button type="button" className="rounded-lg border border-slate-300 px-3 py-2 text-sm font-medium hover:bg-slate-50" onClick={() => void logout()}>Sign out</button>
        </div>
      </header>
      <main className="py-6"><Outlet /></main>
      <footer className="border-t border-slate-200 py-5 text-center text-xs text-slate-400">Electrical Store Management System · Phase 1</footer>
    </div>
  );
}

function RequireAuth() {
  const { user, loading } = useAuth();
  if (loading) return <main className="grid min-h-screen place-items-center p-6"><p className="text-sm text-slate-600">Checking your session…</p></main>;
  return user ? <Layout /> : <Navigate to="/login" replace />;
}
function AdminOnly() {
  const { user } = useAuth();
  return user?.role === 'ADMIN' ? <Users /> : <Navigate to="/" replace />;
}

export default function App() {
  return <Routes>
    <Route path="/login" element={<Login />} />
    <Route element={<RequireAuth />}>
      <Route index element={<Dashboard />} />
      <Route path="users" element={<AdminOnly />} />
    </Route>
    <Route path="*" element={<Navigate to="/" replace />} />
  </Routes>;
}

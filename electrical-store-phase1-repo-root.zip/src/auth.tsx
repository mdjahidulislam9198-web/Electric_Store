import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { call, session, setAuthLostHandler } from './api/client';
import { deriveKey, randomSalt, ITERATIONS } from './lib/crypto';

export type User = {
  id: string;
  username: string;
  fullName: string;
  role: 'ADMIN' | 'STAFF';
  expiresAt: string;
};
type LoginParams = { salt: string; iterations: number };
type LoginResult = { token: string; expiresAt: string; user: Omit<User, 'expiresAt'> };
type AuthContextValue = {
  user: User | null;
  loading: boolean;
  login: (username: string, password: string) => Promise<void>;
  activate: (username: string, setupCode: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);
export function useAuth(): AuthContextValue {
  const value = useContext(AuthContext);
  if (!value) throw new Error('useAuth must be used inside AuthProvider.');
  return value;
}

function normalizeUsername(value: string): string { return value.trim().toLowerCase(); }
function validLoginResult(value: LoginResult): boolean {
  return Boolean(value && typeof value.token === 'string' && value.token &&
    typeof value.expiresAt === 'string' && !Number.isNaN(Date.parse(value.expiresAt)) &&
    value.user && typeof value.user.id === 'string' && typeof value.user.username === 'string' &&
    typeof value.user.fullName === 'string' && ['ADMIN', 'STAFF'].includes(value.user.role));
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setAuthLostHandler(() => setUser(null));
    if (!session.get()) {
      setLoading(false);
      return () => setAuthLostHandler(() => undefined);
    }
    let active = true;
    call<User>('me')
      .then(restored => {
        if (active && restored && ['ADMIN', 'STAFF'].includes(restored.role) &&
          typeof restored.expiresAt === 'string' && !Number.isNaN(Date.parse(restored.expiresAt))) setUser(restored);
        else if (active) { session.clear(); setUser(null); }
      })
      .catch(() => { if (active) { session.clear(); setUser(null); } })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; setAuthLostHandler(() => undefined); };
  }, []);

  async function login(username: string, password: string): Promise<void> {
    const normalized = normalizeUsername(username);
    if (!normalized || !password) throw new Error('Enter your username and password.');
    const params = await call<LoginParams>('getLoginParams', { username: normalized });
    if (!params || typeof params.salt !== 'string' || !Number.isInteger(params.iterations) || params.iterations < 1) {
      throw new Error('The server returned invalid login parameters. Contact the administrator.');
    }
    const key = await deriveKey(password, params.salt, params.iterations);
    const result = await call<LoginResult>('login', { username: normalized, key });
    if (!validLoginResult(result)) throw new Error('The server returned an invalid login response.');
    session.set(result.token);
    setUser({ ...result.user, expiresAt: result.expiresAt });
  }

  async function activate(username: string, setupCode: string, password: string): Promise<void> {
    const normalized = normalizeUsername(username);
    if (!normalized || !setupCode.trim()) throw new Error('Enter your username and setup code.');
    if (password.length < 10) throw new Error('Choose a password of at least 10 characters.');
    const salt = randomSalt();
    const key = await deriveKey(password, salt, ITERATIONS);
    await call('activateAccount', { username: normalized, setupCode: setupCode.trim(), key, salt, iterations: ITERATIONS });
    await login(normalized, password);
  }

  async function logout(): Promise<void> {
    // Clear the UI/session immediately; a slow or offline server must not trap the user in the app.
    const hadSession = Boolean(session.get());
    // Start the request before clearing sessionStorage so the token is included in its body.
    const serverLogout = hadSession ? call('logout') : Promise.resolve();
    session.clear();
    setUser(null);
    try { await serverLogout; } catch { /* local sign-out is already complete */ }
  }

  const value = useMemo(() => ({ user, loading, login, activate, logout }), [user, loading]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

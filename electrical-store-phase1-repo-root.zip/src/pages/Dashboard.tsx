import { useEffect, useState } from 'react';
import { ApiError, call } from '../api/client';
import { useAuth } from '../auth';

type ServerState = 'checking' | 'connected' | 'error';
export default function Dashboard() {
  const { user } = useAuth();
  const [serverState, setServerState] = useState<ServerState>('checking');
  const [serverMessage, setServerMessage] = useState('Checking the backend connection…');
  const [apiVersion, setApiVersion] = useState('');

  async function checkConnection() {
    setServerState('checking'); setServerMessage('Checking the backend connection…');
    try {
      const result = await call<{ apiVersion?: string }>('ping');
      setApiVersion(typeof result?.apiVersion === 'string' ? result.apiVersion : '');
      setServerState('connected'); setServerMessage('The frontend can communicate with the backend.');
    } catch (cause) {
      setServerState('error');
      setServerMessage(cause instanceof ApiError ? cause.message : 'The backend connection could not be verified.');
    }
  }
  useEffect(() => { void checkConnection(); }, []);

  return <div className="space-y-6">
    <div><p className="text-sm font-medium text-slate-500">Overview</p><h1 className="mt-1 text-2xl font-semibold tracking-tight text-slate-900">Welcome, {user?.fullName}</h1><p className="mt-1 text-sm text-slate-500">Your store workspace is ready for the next development phases.</p></div>
    <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
      <div className="flex flex-wrap items-start justify-between gap-4"><div><h2 className="font-semibold text-slate-900">Backend connection</h2><p className="mt-1 text-sm text-slate-500">Connectivity check through your configured Cloudflare Worker.</p></div>
        <span className={`inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-semibold ${serverState === 'connected' ? 'bg-emerald-50 text-emerald-700' : serverState === 'error' ? 'bg-red-50 text-red-700' : 'bg-slate-100 text-slate-600'}`}><span className={`h-2 w-2 rounded-full ${serverState === 'connected' ? 'bg-emerald-500' : serverState === 'error' ? 'bg-red-500' : 'animate-pulse bg-slate-400'}`} />{serverState === 'connected' ? 'Connected' : serverState === 'error' ? 'Connection issue' : 'Checking'}</span></div>
      <p className="mt-4 text-sm text-slate-600">{serverMessage}</p>
      {apiVersion && <p className="mt-1 text-xs text-slate-400">API version: {apiVersion}</p>}
      <button type="button" onClick={() => void checkConnection()} disabled={serverState === 'checking'} className="mt-4 rounded-lg border border-slate-300 px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50">{serverState === 'checking' ? 'Checking…' : 'Check again'}</button>
    </section>
    <section><div className="mb-3"><h2 className="font-semibold text-slate-900">Application modules</h2><p className="mt-1 text-sm text-slate-500">These modules are planned for subsequent development phases.</p></div>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{[
        ['Inventory', 'Products, stock levels and stock movements'], ['Purchases', 'Supplier purchases and payable balances'], ['Sales', 'Customer invoices, payments and receivables'], ['Accounting', 'Ledgers, journals and financial reports'],
      ].map(([title, description]) => <article key={title} className="rounded-xl border border-dashed border-slate-300 bg-white/70 p-4"><p className="font-semibold text-slate-800">{title}</p><p className="mt-1 text-sm leading-5 text-slate-500">{description}</p><span className="mt-3 inline-block rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-500">Planned</span></article>)}</div>
    </section>
  </div>;
}

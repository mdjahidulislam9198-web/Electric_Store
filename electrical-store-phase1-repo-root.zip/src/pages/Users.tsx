import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { call } from '../api/client';
import { useAuth } from '../auth';

type StoreUser = { id: string; username: string; fullName: string; role: 'ADMIN' | 'STAFF'; isActive: boolean; activated: boolean; locked: boolean };
const inputClass = 'min-w-0 rounded-xl border border-slate-300 bg-white px-3 py-2.5 text-sm outline-none focus:border-slate-500 focus:ring-4 focus:ring-slate-100';

export default function Users() {
  const { user: currentUser } = useAuth();
  const [users, setUsers] = useState<StoreUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [setupCode, setSetupCode] = useState('');
  const [codeFor, setCodeFor] = useState('');
  const [username, setUsername] = useState('');
  const [fullName, setFullName] = useState('');
  const [role, setRole] = useState<'STAFF' | 'ADMIN'>('STAFF');

  const load = useCallback(async () => {
    setError('');
    try {
      const result = await call<StoreUser[]>('listUsers');
      if (!Array.isArray(result)) throw new Error('The server returned an invalid user list.');
      setUsers(result);
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Could not load users.'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { void load(); }, [load]);

  async function createUser(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const normalized = username.trim().toLowerCase();
    const name = fullName.trim();
    if (!normalized || !name) { setError('Enter both a username and full name.'); return; }
    setCreating(true); setError(''); setNotice(''); setSetupCode('');
    try {
      const result = await call<{ setupCode: string }>('createUser', { username: normalized, fullName: name, role });
      if (!result || typeof result.setupCode !== 'string' || !result.setupCode) throw new Error('The user was created, but the server did not return a setup code. Check the Users list before retrying.');
      setSetupCode(result.setupCode); setCodeFor(normalized);
      setNotice(`Account created for ${normalized}. Share the setup code privately; it is displayed here only.`);
      setUsername(''); setFullName(''); setRole('STAFF');
      await load();
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Could not create user.'); }
    finally { setCreating(false); }
  }

  async function toggleActive(user: StoreUser) {
    if (user.id === currentUser?.id && user.isActive) {
      setError('You cannot disable your own currently signed-in account. Ask another Admin to manage your access.');
      return;
    }
    const action = user.isActive ? 'disable' : 'enable';
    if (!window.confirm(`Are you sure you want to ${action} ${user.username}?`)) return;
    setBusyId(user.id); setError(''); setNotice('');
    try {
      await call('setUserActive', { userId: user.id, isActive: !user.isActive });
      setNotice(`${user.username} has been ${user.isActive ? 'disabled' : 'enabled'}.`);
      await load();
    } catch (cause) { setError(cause instanceof Error ? cause.message : `Could not ${action} user.`); }
    finally { setBusyId(null); }
  }

  async function issueSetupCode(user: StoreUser) {
    if (!window.confirm(`Issue a new one-time activation/recovery code for ${user.username}? Any previous unused setup code may become invalid.`)) return;
    setBusyId(user.id); setError(''); setNotice(''); setSetupCode('');
    try {
      const result = await call<{ setupCode: string }>('resetSetupCode', { userId: user.id });
      if (!result || typeof result.setupCode !== 'string' || !result.setupCode) throw new Error('The server did not return a setup code.');
      setSetupCode(result.setupCode); setCodeFor(user.username);
      setNotice(`A new one-time code was issued for ${user.username}. It is valid for 24 hours according to the backend setup guide. Give it to the user privately.`);
      await load();
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Could not issue a setup code.'); }
    finally { setBusyId(null); }
  }

  async function copyCode() {
    try { await navigator.clipboard.writeText(setupCode); setNotice('Setup code copied. Share it with the user privately.'); }
    catch { setError('Clipboard access was blocked. Select and copy the code manually.'); }
  }

  return (
    <div className="space-y-6">
      <div><p className="text-sm font-medium text-slate-500">Administration</p><h1 className="mt-1 text-2xl font-semibold tracking-tight text-slate-900">User management</h1><p className="mt-1 text-sm text-slate-500">Create accounts, issue one-time setup codes and manage access.</p></div>

      {error && <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</p>}
      {notice && <p role="status" className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">{notice}</p>}
      {setupCode && <section className="rounded-2xl border border-amber-200 bg-amber-50 p-4 sm:p-5">
        <div className="flex flex-wrap items-start justify-between gap-3"><div><h2 className="font-semibold text-amber-950">One-time setup code for {codeFor}</h2><p className="mt-1 text-sm text-amber-800">This code is sensitive. Share it privately and do not send it in a public channel.</p></div>
          <button type="button" onClick={() => { setSetupCode(''); setCodeFor(''); }} className="text-sm text-amber-800 underline">Dismiss</button></div>
        <div className="mt-3 flex flex-wrap items-center gap-2"><code className="min-w-0 flex-1 break-all rounded-lg border border-amber-200 bg-white px-3 py-3 font-mono text-base font-semibold tracking-wider text-slate-900">{setupCode}</code>
          <button type="button" onClick={() => void copyCode()} className="rounded-lg bg-amber-900 px-4 py-3 text-sm font-semibold text-white hover:bg-amber-800">Copy code</button></div>
      </section>}

      <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
        <h2 className="font-semibold text-slate-900">Add a user</h2><p className="mb-4 mt-1 text-sm text-slate-500">A one-time activation code will be generated after creation.</p>
        <form onSubmit={createUser} className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-1"><label htmlFor="new-username" className="text-xs font-medium text-slate-600">Username</label><input id="new-username" className={inputClass + ' w-full'} placeholder="e.g. store.staff" value={username} onChange={e => setUsername(e.target.value)} required disabled={creating} /></div>
          <div className="space-y-1"><label htmlFor="new-fullname" className="text-xs font-medium text-slate-600">Full name</label><input id="new-fullname" className={inputClass + ' w-full'} placeholder="Full name" value={fullName} onChange={e => setFullName(e.target.value)} required disabled={creating} /></div>
          <div className="space-y-1"><label htmlFor="new-role" className="text-xs font-medium text-slate-600">Role</label><select id="new-role" className={inputClass + ' w-full'} value={role} onChange={e => setRole(e.target.value as 'STAFF' | 'ADMIN')} disabled={creating}><option value="STAFF">Staff</option><option value="ADMIN">Admin</option></select></div>
          <div className="flex items-end"><button type="submit" disabled={creating} className="w-full rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white hover:bg-slate-700 disabled:cursor-not-allowed disabled:opacity-60">{creating ? 'Creating…' : 'Create user'}</button></div>
        </form>
      </section>

      <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 px-4 py-4 sm:px-5"><div><h2 className="font-semibold text-slate-900">Store users</h2><p className="text-xs text-slate-500">{users.length} account{users.length === 1 ? '' : 's'}</p></div><button type="button" onClick={() => void load()} disabled={loading} className="rounded-lg border border-slate-300 px-3 py-2 text-sm font-medium hover:bg-slate-50 disabled:opacity-50">{loading ? 'Refreshing…' : 'Refresh'}</button></div>
        {loading ? <p className="p-6 text-sm text-slate-500">Loading users…</p> : users.length === 0 ? <p className="p-6 text-sm text-slate-500">No users were returned by the server.</p> :
          <div className="overflow-x-auto"><table className="w-full min-w-[680px] text-left text-sm"><thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500"><tr><th scope="col" className="px-5 py-3">User</th><th scope="col" className="px-3 py-3">Role</th><th scope="col" className="px-3 py-3">Status</th><th scope="col" className="px-5 py-3 text-right">Actions</th></tr></thead>
            <tbody className="divide-y divide-slate-100">{users.map(user => <tr key={user.id}>
              <td className="px-5 py-3"><p className="font-medium text-slate-900">{user.fullName}</p><p className="text-xs text-slate-500">{user.username}</p></td>
              <td className="px-3 py-3"><span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-700">{user.role}</span></td>
              <td className="px-3 py-3"><span className={`inline-flex items-center gap-1.5 text-xs font-medium ${!user.isActive ? 'text-red-700' : user.locked ? 'text-amber-700' : user.activated ? 'text-emerald-700' : 'text-slate-500'}`}><span className={`h-1.5 w-1.5 rounded-full ${!user.isActive ? 'bg-red-500' : user.locked ? 'bg-amber-500' : user.activated ? 'bg-emerald-500' : 'bg-slate-400'}`} />{!user.isActive ? 'Disabled' : user.locked ? 'Locked' : user.activated ? 'Active' : 'Awaiting activation'}</span></td>
              <td className="space-x-3 whitespace-nowrap px-5 py-3 text-right"><button type="button" disabled={busyId === user.id} onClick={() => void issueSetupCode(user)} className="text-xs font-medium text-slate-600 underline underline-offset-4 hover:text-slate-950 disabled:opacity-50">Issue setup code</button><button type="button" disabled={busyId === user.id} onClick={() => void toggleActive(user)} className={`text-xs font-semibold underline underline-offset-4 disabled:opacity-50 ${user.isActive ? 'text-red-700' : 'text-emerald-700'}`}>{busyId === user.id ? 'Working…' : user.isActive ? 'Disable' : 'Enable'}</button></td>
            </tr>)}</tbody></table></div>}
      </section>
      <p className="text-xs leading-5 text-slate-500">Important: hiding the Users page from Staff is only a frontend convenience. The Apps Script backend must enforce Admin permissions for every user-management API action.</p>
    </div>
  );
}

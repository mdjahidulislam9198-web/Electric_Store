import { useState, type FormEvent } from 'react';
import { Navigate } from 'react-router-dom';
import { ApiError } from '../api/client';
import { useAuth } from '../auth';

const inputClass = 'w-full rounded-xl border border-slate-300 bg-white px-3.5 py-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-slate-500 focus:ring-4 focus:ring-slate-100 disabled:bg-slate-100';

export default function Login() {
  const { user, login, activate } = useAuth();
  const [mode, setMode] = useState<'login' | 'activate'>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  if (user) return <Navigate to="/" replace />;

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError('');
    const normalized = username.trim().toLowerCase();
    if (!normalized) { setError('Enter your username.'); return; }
    if (mode === 'activate') {
      if (password.length < 10) { setError('Choose a password of at least 10 characters.'); return; }
      if (password !== confirm) { setError('The passwords do not match.'); return; }
      if (!code.trim()) { setError('Enter the setup code provided by your administrator.'); return; }
    }
    setBusy(true);
    try {
      if (mode === 'login') await login(normalized, password);
      else await activate(normalized, code, password);
      setPassword(''); setConfirm(''); setCode('');
    } catch (cause) {
      setError(cause instanceof ApiError ? cause.message : cause instanceof Error ? cause.message : 'Something went wrong. Please try again.');
    } finally { setBusy(false); }
  }

  function switchMode() {
    setMode(current => current === 'login' ? 'activate' : 'login');
    setError(''); setPassword(''); setConfirm(''); setCode('');
  }

  return (
    <main className="relative grid min-h-screen place-items-center overflow-hidden bg-slate-100 px-4 py-10">
      <div className="pointer-events-none absolute -left-28 -top-28 h-80 w-80 rounded-full bg-slate-200/70 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-36 -right-24 h-96 w-96 rounded-full bg-blue-100/70 blur-3xl" />
      <section className="relative w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-xl shadow-slate-200/60 sm:p-8">
        <div className="mb-7 flex items-center gap-3">
          <div className="grid h-12 w-12 place-items-center rounded-2xl bg-slate-900 text-xl font-bold text-white" aria-hidden="true">E</div>
          <div><p className="text-lg font-semibold tracking-tight text-slate-900">Electrical Store</p><p className="text-sm text-slate-500">Management system</p></div>
        </div>
        <h1 className="text-2xl font-semibold tracking-tight text-slate-900">{mode === 'login' ? 'Welcome back' : 'Activate your account'}</h1>
        <p className="mb-6 mt-1 text-sm leading-6 text-slate-500">{mode === 'login' ? 'Sign in with your store account to continue.' : 'Use the one-time setup code provided by your administrator.'}</p>

        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-1.5"><label htmlFor="username" className="text-sm font-medium text-slate-700">Username</label>
            <input id="username" className={inputClass} placeholder="Enter your username" autoCapitalize="none" autoComplete="username" value={username} onChange={event => setUsername(event.target.value)} required disabled={busy} /></div>
          {mode === 'activate' && <div className="space-y-1.5"><label htmlFor="setup-code" className="text-sm font-medium text-slate-700">Setup code</label>
            <input id="setup-code" className={inputClass} placeholder="XXXX-XXXX-XXXX" autoCapitalize="characters" autoComplete="one-time-code" value={code} onChange={event => setCode(event.target.value)} required disabled={busy} /></div>}
          <div className="space-y-1.5"><label htmlFor="password" className="text-sm font-medium text-slate-700">{mode === 'login' ? 'Password' : 'Create password'}</label>
            <input id="password" className={inputClass} type="password" placeholder={mode === 'login' ? 'Enter your password' : 'At least 10 characters'} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} value={password} onChange={event => setPassword(event.target.value)} required disabled={busy} minLength={mode === 'activate' ? 10 : undefined} /></div>
          {mode === 'activate' && <div className="space-y-1.5"><label htmlFor="confirm-password" className="text-sm font-medium text-slate-700">Confirm password</label>
            <input id="confirm-password" className={inputClass} type="password" placeholder="Enter the password again" autoComplete="new-password" value={confirm} onChange={event => setConfirm(event.target.value)} required disabled={busy} /></div>}
          {error && <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-3 py-2.5 text-sm leading-5 text-red-700">{error}</p>}
          <button type="submit" disabled={busy} className="w-full rounded-xl bg-slate-900 px-4 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-slate-700 focus:outline-none focus:ring-4 focus:ring-slate-200 disabled:cursor-not-allowed disabled:opacity-60">
            {busy ? 'Please wait…' : mode === 'login' ? 'Sign in' : 'Activate account'}
          </button>
        </form>
        <div className="mt-6 border-t border-slate-100 pt-5 text-center">
          <button type="button" className="text-sm font-medium text-slate-600 underline decoration-slate-300 underline-offset-4 hover:text-slate-900" onClick={switchMode} disabled={busy}>
            {mode === 'login' ? 'First time here? Activate your account' : 'Already activated? Back to sign in'}
          </button>
        </div>
        <p className="mt-6 text-center text-xs text-slate-400">Authorized store users only</p>
      </section>
    </main>
  );
}

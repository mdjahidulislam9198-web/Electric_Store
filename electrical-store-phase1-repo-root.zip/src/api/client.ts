// The only frontend module that communicates with the backend.
// Keep the action names and request envelope compatible with the existing Apps Script API.
export class ApiError extends Error {
  readonly code: string;
  readonly status?: number;
  constructor(code: string, message: string, status?: number) {
    super(message);
    this.name = 'ApiError';
    this.code = code;
    this.status = status;
  }
}

const API_URL = (import.meta.env.VITE_API_URL ?? '').trim().replace(/\/+$/, '');
const SESSION_KEY = 'store.token';
const REQUEST_TIMEOUT_MS = 30_000;

type ApiEnvelope<T> = { ok: true; data: T } | { ok: false; code?: string; message?: string };

export const session = {
  get(): string | null {
    try { return sessionStorage.getItem(SESSION_KEY); } catch { return null; }
  },
  set(token: string): void {
    try { sessionStorage.setItem(SESSION_KEY, token); }
    catch { throw new ApiError('STORAGE', 'This browser cannot store the session. Enable site storage and try again.'); }
  },
  clear(): void {
    try { sessionStorage.removeItem(SESSION_KEY); } catch { /* storage may be unavailable */ }
  },
};

let onAuthLost: () => void = () => undefined;
export function setAuthLostHandler(handler: () => void): void { onAuthLost = handler; }

/** One request key per user action. Reuse the same key only when retrying that same write. */
export function newRequestKey(): string {
  if (typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
}

export async function call<T = unknown>(
  action: string,
  payload: Record<string, unknown> = {},
  requestKey: string = newRequestKey(),
): Promise<T> {
  if (!API_URL) throw new ApiError('CONFIG', 'The API address is not configured. Set the GitHub Actions variable API_URL.');

  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  let response: Response;
  try {
    response = await fetch(API_URL, {
      method: 'POST',
      redirect: 'follow',
      credentials: 'omit',
      signal: controller.signal,
      // text/plain avoids a CORS preflight, matching the connectivity test.
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ action, payload, token: session.get(), requestKey, apiVersion: '1.0' }),
    });
  } catch (error) {
    if (error instanceof DOMException && error.name === 'AbortError') {
      throw new ApiError('TIMEOUT', 'The server did not respond within 30 seconds. Check the connection before trying again.');
    }
    throw new ApiError('NETWORK', 'Cannot reach the server. Check your internet connection and try again.');
  } finally {
    window.clearTimeout(timeout);
  }

  let body: unknown;
  try { body = await response.json(); }
  catch {
    throw new ApiError('BAD_RESPONSE', `The server returned an unreadable response (HTTP ${response.status}).`, response.status);
  }

  if (!body || typeof body !== 'object' || !('ok' in body)) {
    throw new ApiError('BAD_RESPONSE', 'The server response did not match the expected API format.', response.status);
  }

  const envelope = body as ApiEnvelope<T>;
  if (!response.ok || envelope.ok !== true) {
    const failure = envelope as Extract<ApiEnvelope<T>, { ok: false }>;
    const code = typeof failure.code === 'string' ? failure.code : `HTTP_${response.status}`;
    const message = typeof failure.message === 'string' && failure.message.trim()
      ? failure.message : `The request failed (HTTP ${response.status}).`;
    if (code === 'UNAUTHENTICATED' || code === 'SESSION_EXPIRED') {
      session.clear();
      onAuthLost();
    }
    throw new ApiError(code, message, response.status);
  }
  return envelope.data;
}
